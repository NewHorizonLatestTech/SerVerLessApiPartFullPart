# Serverless-APIs
How to make Serverless Scalable APIs in baby steps using AWS CDK

[Link to slides](https://docs.google.com/presentation/d/1O9Ksx_FvwQ21swpYToxJ_GNn0OH74h3CHwvlHZ9Hc5c/edit?usp=sharing)
