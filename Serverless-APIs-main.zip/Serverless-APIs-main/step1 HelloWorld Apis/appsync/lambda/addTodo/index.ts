import {Todo} from "..";

 function addTodo(todo: Todo):Todo {
    

    console.log('mutation started')

    return todo
}

export default addTodo;