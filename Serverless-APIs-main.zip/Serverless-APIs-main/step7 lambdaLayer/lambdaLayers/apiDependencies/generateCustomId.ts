export const generateId = () => {
  const id = Math.floor(Math.random() * 10000);
  return id
}

