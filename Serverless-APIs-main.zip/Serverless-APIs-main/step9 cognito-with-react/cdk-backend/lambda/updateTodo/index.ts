import {Todo} from "..";

 function updateTodo(todo: Todo):Todo {
    
    console.log('mutation started')

    return todo
}

export default updateTodo;